#pragma once

void demo_picker_init();
void demo_picker_update();
void demo_picker_shutdown();