#define SOKOL_TIME_IMPL
#include "sokol_time.h"