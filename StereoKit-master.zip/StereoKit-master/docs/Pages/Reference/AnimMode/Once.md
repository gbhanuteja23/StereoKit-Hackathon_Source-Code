---
layout: default
title: AnimMode.Once
description: When the animation reaches the end, it will freeze in-place.
---
# [AnimMode]({{site.url}}/Pages/Reference/AnimMode.html).Once

<div class='signature' markdown='1'>
static [AnimMode]({{site.url}}/Pages/Reference/AnimMode.html) Once
</div>

## Description
When the animation reaches the end, it will freeze
in-place.

