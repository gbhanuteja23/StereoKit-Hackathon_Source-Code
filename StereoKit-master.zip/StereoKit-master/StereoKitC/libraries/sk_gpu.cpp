#define SKG_IMPL
#include "sk_gpu.h"