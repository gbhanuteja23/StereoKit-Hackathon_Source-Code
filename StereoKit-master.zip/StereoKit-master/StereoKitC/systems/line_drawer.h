#pragma once

namespace sk {

bool line_drawer_init    ();
void line_drawer_update  ();
void line_drawer_shutdown();

} // namespace sk