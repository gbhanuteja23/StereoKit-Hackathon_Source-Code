﻿namespace StereoKitDocumenter
{
	class DocParam
	{
		public string name;
		public string summary;
	}
}
