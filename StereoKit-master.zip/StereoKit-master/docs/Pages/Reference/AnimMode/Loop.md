---
layout: default
title: AnimMode.Loop
description: If the animation reaches the end, it will always loop back around to the start again.
---
# [AnimMode]({{site.url}}/Pages/Reference/AnimMode.html).Loop

<div class='signature' markdown='1'>
static [AnimMode]({{site.url}}/Pages/Reference/AnimMode.html) Loop
</div>

## Description
If the animation reaches the end, it will always loop
back around to the start again.

