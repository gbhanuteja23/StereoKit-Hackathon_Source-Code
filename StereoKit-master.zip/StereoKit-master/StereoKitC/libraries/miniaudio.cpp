#define _POSIX_C_SOURCE 199309L
#define MA_NO_OPENSL
#define MA_NO_FLAC
//#define MA_NO_MP3
#define MA_NO_ENCODING
#define MINIAUDIO_IMPLEMENTATION
#include "miniaudio.h"