#pragma once

#include "stereokit_ui.h"

namespace sk {

bool ui_init       ();
void ui_update     ();
void ui_update_late();
void ui_shutdown   ();

}