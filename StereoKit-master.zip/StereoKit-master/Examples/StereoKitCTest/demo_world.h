#pragma once

void demo_world_init();
void demo_world_update();
void demo_world_shutdown();