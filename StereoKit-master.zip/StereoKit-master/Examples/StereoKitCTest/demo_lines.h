#pragma once

void demo_lines_init();
void demo_lines_update();
void demo_lines_shutdown();