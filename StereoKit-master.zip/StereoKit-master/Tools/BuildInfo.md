# StereoKit v0.3.4 Build Information

## Build Sizes:

| Platform | Arch  | Size, kb | Size, bytes |
| -------- | ----- | -------- | ----------- |
| Win32    | x64   |    1,777 |   1,819,648 |
| Linux    | x64   |    3,812 |   3,903,096 |
| UWP      | x64   |    1,803 |   1,846,272 |
| UWP      | ARM64 |    1,750 |   1,792,000 |
| Android  | ARM64 |    2,715 |   2,780,320 |
| UWP      | ARM   |    1,362 |   1,395,200 |
