---
name: Feature request
about: Suggest an idea for this project
title: ''
labels: ''
assignees: ''

---

## Describe the feature
_What would you like to see added? Details and references are appreciated._

## An example use-case
_How do you imagine this feature being used? What's the context?_
