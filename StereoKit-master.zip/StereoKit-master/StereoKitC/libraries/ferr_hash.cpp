#define FERR_HASH_IMPL
#include "ferr_hash.h"