---
layout: default
title: BtnState.Any
description: Matches with all states!
---
# [BtnState]({{site.url}}/Pages/Reference/BtnState.html).Any

<div class='signature' markdown='1'>
static [BtnState]({{site.url}}/Pages/Reference/BtnState.html) Any
</div>

## Description
Matches with all states!

