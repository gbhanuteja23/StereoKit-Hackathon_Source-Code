﻿interface ITest
{
	void Initialize();
	void Update();
	void Shutdown();
}