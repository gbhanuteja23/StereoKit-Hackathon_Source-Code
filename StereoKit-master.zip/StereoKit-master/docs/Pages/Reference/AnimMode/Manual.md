---
layout: default
title: AnimMode.Manual
description: The animation will not progress on its own, and instead must be driven by providing information to the model's AnimTime or AnimCompletion properties.
---
# [AnimMode]({{site.url}}/Pages/Reference/AnimMode.html).Manual

<div class='signature' markdown='1'>
static [AnimMode]({{site.url}}/Pages/Reference/AnimMode.html) Manual
</div>

## Description
The animation will not progress on its own, and instead
must be driven by providing information to the model's AnimTime
or AnimCompletion properties.

