#pragma once

void demo_mic_init();
void demo_mic_update();
void demo_mic_shutdown();