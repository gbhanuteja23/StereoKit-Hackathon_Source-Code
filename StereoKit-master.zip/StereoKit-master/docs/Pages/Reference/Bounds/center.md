---
layout: default
title: Bounds.center
description: The exact center of the Bounds!
---
# [Bounds]({{site.url}}/Pages/Reference/Bounds.html).center

<div class='signature' markdown='1'>
[Vec3]({{site.url}}/Pages/Reference/Vec3.html) center
</div>

## Description
The exact center of the Bounds!

