#pragma once

void demo_ui_init();
void demo_ui_update();
void demo_ui_shutdown();