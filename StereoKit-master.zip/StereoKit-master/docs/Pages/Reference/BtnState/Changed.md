---
layout: default
title: BtnState.Changed
description: Has the button just changed state this frame?
---
# [BtnState]({{site.url}}/Pages/Reference/BtnState.html).Changed

<div class='signature' markdown='1'>
static [BtnState]({{site.url}}/Pages/Reference/BtnState.html) Changed
</div>

## Description
Has the button just changed state this frame?

