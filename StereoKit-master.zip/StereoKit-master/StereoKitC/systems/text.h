#pragma once

namespace sk {

void text_update();
void text_shutdown();

} // namespace sk