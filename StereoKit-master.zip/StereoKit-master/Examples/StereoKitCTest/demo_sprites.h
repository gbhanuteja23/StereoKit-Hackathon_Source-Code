#pragma once

void demo_sprites_init();
void demo_sprites_update();
void demo_sprites_shutdown();