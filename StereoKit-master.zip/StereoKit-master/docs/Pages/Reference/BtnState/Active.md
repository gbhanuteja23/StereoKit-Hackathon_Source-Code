---
layout: default
title: BtnState.Active
description: Is the button currently down, pressed?
---
# [BtnState]({{site.url}}/Pages/Reference/BtnState.html).Active

<div class='signature' markdown='1'>
static [BtnState]({{site.url}}/Pages/Reference/BtnState.html) Active
</div>

## Description
Is the button currently down, pressed?

