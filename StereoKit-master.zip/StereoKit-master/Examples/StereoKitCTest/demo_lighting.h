#pragma once

void demo_lighting_init();
void demo_lighting_update();
void demo_lighting_shutdown();