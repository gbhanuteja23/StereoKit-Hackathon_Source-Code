#pragma once

void demo_basics_init();
void demo_basics_update();
void demo_basics_shutdown();